import { createContext } from "react";

const ContextError = createContext();

export default ContextError;