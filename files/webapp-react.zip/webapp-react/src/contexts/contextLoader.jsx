import { createContext } from "react";

const ContextLoader = createContext();

export default ContextLoader;