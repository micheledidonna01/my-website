const Error = ()=>{
    return <>
        <div className='alert alert-danger'>C'è stato un problema durante il caricamento</div>
    </>
}

export default Error;