const NewMovie = ()=>{
    return <>
    </>
}

export default NewMovie;